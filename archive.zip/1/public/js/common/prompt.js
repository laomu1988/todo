web.prompt = function (data) {
    web.dialog('prompt', data);
};