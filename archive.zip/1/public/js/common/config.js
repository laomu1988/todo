web.config = $.extend(web.config, {
    server: '/api/'
});
var config = web.config;