var web = typeof web == 'undefined' ? {} : web;

// import('config.js');
// import('ajax.js');
// import('services.js');

// import('cookie.js');
// import('router.js');

// import('validate.js');
// import('formSubmit.js');

// import('dialog.js');
// import('prompt.js');